package com.psl.question2;

public class Product {
	
	String productName,productId;
	
     public String getProductId() {
		return productId;
	}
     public String getProductName() {
		return productName;
	}
     
     public void setProductId(String productId) {
		this.productId = productId;
	}
     public void setProductName(String productName) {
		this.productName = productName;
	}
}
