package com.psl.question2;

public enum ProductData {
	
	Car("P1"),Bus("P2"),scooter("P3"),Plane("P4"),Ship("P5"),Truck("P6"),Rickshaw("P7"),Bike("P8"),Cycle("P9"),Helicopter("P10");
	
	
	String val;
	private ProductData(String val) {
		// TODO Auto-generated constructor stub
		this.val=val;
	}

}
