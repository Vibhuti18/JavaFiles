package com.psl.question3;

import java.util.Scanner;
import java.util.Vector;

public class Name {

	String firstName, lastName;

	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	

}
