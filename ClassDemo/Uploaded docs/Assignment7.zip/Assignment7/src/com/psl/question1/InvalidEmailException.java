package com.psl.question1;

public class InvalidEmailException extends Exception {
	
	public InvalidEmailException(String msg) {
		// TODO Auto-generated constructor stub
		
		super(msg);
	}

}
