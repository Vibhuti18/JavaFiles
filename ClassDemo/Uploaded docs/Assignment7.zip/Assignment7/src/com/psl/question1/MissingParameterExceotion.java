package com.psl.question1;

public class MissingParameterExceotion extends Exception{
	
	public MissingParameterExceotion(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
