package com.psl.question1;

public class MissingPhoneException extends Exception {

	public MissingPhoneException(String msg) {
		// TODO Auto-generated constructor stub

		super(msg);
	}

}
