package com.psl.question1;

public class PopException extends Exception {
	public PopException(String s) {
		// TODO Auto-generated constructor stub

		super(s);
	}

}
