package com.psl.question1;

public class PushException extends Exception{
	
	public PushException(String msg) {
		// TODO Auto-generated constructor stub
		
		super(msg);
	}

}
