package com.psl.question4;

public class ImproperArgs extends Exception{
	
	public ImproperArgs(String str) {
		// TODO Auto-generated constructor stub
		
		super(str);
	}

}
