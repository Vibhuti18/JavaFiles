package com.psl.question4;

public class ImproperId extends Exception {
	
	public ImproperId(String s) {
		// TODO Auto-generated constructor stub
		super(s);
	}

}
