package com.psl.question4;

public class ImproperLanguage extends Exception {
	
	public ImproperLanguage(String s) {
		// TODO Auto-generated constructor stub
		super(s);
	}

}
