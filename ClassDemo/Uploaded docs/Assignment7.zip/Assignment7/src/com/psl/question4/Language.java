package com.psl.question4;

public enum Language {
	
	English,Hindi,Marathi

}
