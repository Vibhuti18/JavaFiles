package com.psl.question2;

import java.util.Comparator;

public class CompareDuration implements Comparator<Movies> {
	
	@Override
	public int compare(Movies o1, Movies o2) {
		// TODO Auto-generated method stub
		return 0;
	}

}
