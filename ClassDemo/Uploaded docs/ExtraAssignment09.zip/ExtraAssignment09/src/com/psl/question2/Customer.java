package com.psl.question2;

public class Customer {
	
	int customerId;
	String customerName;
	double ISD_duration;
	double ISD_per_min;
	double STD_duration;
	double STD_per_min;
	double local_duration;
	double local_per_min;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public double getISD_duration() {
		return ISD_duration;
	}
	public void setISD_duration(double iSD_duration) {
		ISD_duration = iSD_duration;
	}
	public double getISD_per_min() {
		return ISD_per_min;
	}
	public void setISD_per_min(double iSD_per_min) {
		ISD_per_min = iSD_per_min;
	}
	public double getSTD_duration() {
		return STD_duration;
	}
	public void setSTD_duration(double sTD_duration) {
		STD_duration = sTD_duration;
	}
	public double getSTD_per_min() {
		return STD_per_min;
	}
	public void setSTD_per_min(double sTD_per_min) {
		STD_per_min = sTD_per_min;
	}
	public double getLocal_duration() {
		return local_duration;
	}
	public void setLocal_duration(double local_duration) {
		this.local_duration = local_duration;
	}
	public double getLocal_per_min() {
		return local_per_min;
	}
	public void setLocal_per_min(double local_per_min) {
		this.local_per_min = local_per_min;
	}
	
	

}
