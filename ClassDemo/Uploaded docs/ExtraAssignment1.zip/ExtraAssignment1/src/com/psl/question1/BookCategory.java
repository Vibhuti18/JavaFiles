package com.psl.question1;

public enum BookCategory {
	COMPUTER, ART,MATH,HORROR,FICTION,MUSIC;

	
}
