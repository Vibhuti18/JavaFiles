package com.psl.question6;

public class Storage {

	 int count;
	 boolean printed = true;

	public Storage() {
		// TODO Auto-generated constructor stub

		count = 0;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	  public void setPrinted(boolean p) {
          printed = p;
    }

	public boolean isPrinted() {
		return printed;
	}
	  

}
