package com.psl.question5;

public class Arithmetic {
	
	
	
	public int sum;
	public Arithmetic() {
		// TODO Auto-generated constructor stub
		
		sum=0;
	}
	
	public int add(int x,int y)

	{
		return sum = x + y;
	}

}
