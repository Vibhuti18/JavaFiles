package com.psl.question1;

public class IllegalArgumentException extends Exception {

	IllegalArgumentException() {
		//super("Illegal Argument Exception! No is not a natural number");
		super("Illegal Argument Exception! No is not a natural number");
	}
}
