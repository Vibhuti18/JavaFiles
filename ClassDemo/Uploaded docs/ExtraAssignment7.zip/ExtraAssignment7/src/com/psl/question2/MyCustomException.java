package com.psl.question2;

public class MyCustomException extends Exception{
	
	public MyCustomException() {
		// TODO Auto-generated constructor stub
		
		super("promotionsTillDate or NoOfProjects equals zero  ");
	}

}
