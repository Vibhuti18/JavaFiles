package com.psl.question4;

public class EmployeeNameInvalidException extends Exception {

	public EmployeeNameInvalidException() {
		super("The employee name cannot be empty");
		// TODO Auto-generated constructor stub
	}

}
