package com.psl.question1;

public class InvalidData extends Exception{
	
	public InvalidData() {
		// TODO Auto-generated constructor stub
		super("Data format is invalid");
	}

}
