package com.psl.question1;

public class NoDataFound extends Exception{
	
	public NoDataFound() {
		// TODO Auto-generated constructor stub
		super("Data not found for either food or package");
	}

}
