package com.psl.question2;

public enum Grocery {
	Dals, Pulses, Flour, Oil, Rice, Berries, Nuts, DryFruits;

}
