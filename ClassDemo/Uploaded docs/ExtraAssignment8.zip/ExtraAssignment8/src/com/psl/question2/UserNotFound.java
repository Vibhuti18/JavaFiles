package com.psl.question2;

public class UserNotFound extends Exception {

	public UserNotFound() {
		// TODO Auto-generated constructor stub
		System.err.println("USER NOT FOUND");
	}
}
