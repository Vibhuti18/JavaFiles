package com.psl.question3;

public class ContactNotFoundException extends Exception{
	
	public ContactNotFoundException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}

}
