package com.psl.question5;

public class Main {

	public static void main(String[] args) {

		//System.out.println("Add 5 employees");
		EmpManagement ep = new EmpManagement();
	/*	ep.addEmp(101, "Vibhuti", "Margao", "9923334462", 5000000);
		ep.addEmp(102, "Nidhi", "Panjim", "9856231454", 5000000);
		ep.addEmp(103, "Pooja", "Margao", "987456321", 5000000);
		ep.addEmp(104, "Prabhav", "Ponda", "7412853690", 5000000);
		ep.addEmp(105, "Aditi", "Margao", "1236547890", 5000000);
		*/
		//ep.displayAll();
		ep.searchEmp(106);
	}
}
