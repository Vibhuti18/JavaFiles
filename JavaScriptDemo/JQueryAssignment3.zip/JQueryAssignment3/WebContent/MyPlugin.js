(function($){
	$.fn.MyPlugin=function(){
		this.css("color","red").css("fontSize","18px").css("backgroundColor","grey")
	}
	
})(jQuery);