package com.psl;

public class Train {
	
	
	public void atsourceStation() {
		// TODO Auto-generated method stub
		System.out.println("the train is at halt at the source station");
	}
	public void runs() {
		// TODO Auto-generated method stub
		System.out.println("the train is running");
	}

	
	public void atDestinationstation() {
		// TODO Auto-generated method stub
System.out.println("the train is at halt at the destination station");
	}
}
