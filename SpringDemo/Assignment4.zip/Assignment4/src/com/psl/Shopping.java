package com.psl;




public class Shopping {
	
	
	long st;
	public void browses() {
		// TODO Auto-generated method stub
		System.out.println("The customer browses products");
		//st=time;
	}
	
	public void SelectsProduct() {
		// TODO Auto-generated method stub
		System.out.println("the user selects sofa");
		//now he needs to get suggestions
	}
	
	public void addtocart() {
		// TODO Auto-generated method stub
System.out.println("Added item to cart");
	}
	

}
